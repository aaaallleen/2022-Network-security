#ifndef ASSG3_H
#define ASSG3_H
#include <string>
std::string RabinEncyption();
std::string RabinDecryption();
BigNum sqrt_34(BigNum, BigNum);
BigNum sqrt_58(BigNum, BigNum);
void printstring(std::string);
#endif