Network security Assignment 3
Written by 108062135 呂佳恩 in C++
files included: 
    assg3.cpp
    assg3.h
    bignum.cpp
    bignum.h
    primegen.cpp
    primegen.h

Main function is located in assg3.cpp
The function that generates the big prime takes quite a long time, check Primegen.h for previous primes generated