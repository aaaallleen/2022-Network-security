A simple BigNumber calculator for Class COM 5335
Assignment 1 written by 108062135 呂佳恩
There would be a prompt for the input numbers, and the results would be printed out after both a and b are input